<?php
//    session_start();
//    if(empty($_SESSION)){
//        print "<script>location.href='entrar_pagina.php';</script>";
//    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alocaliso</title>
    <!-- Link pro CSS-->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- Link pros icones-->
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
	<!-- Navbar -->
    <header>
        <div class="nav container">
            <i class="bx bx-menu" id="menu-icon"></i>
            <a href="index.php" class="logo">Aloca<span>liso</span></a>
            <ul class="navbar">
            </ul>
        </div>
    </header>
    <br><br>
    <!-- Servicos -->
    <section class="services" id="services">
        <div class="heading">
            <br><br>
            <span>Carros em Destaque</span>
            <h1>Para todos os gostos e tipos. <br> </h1>
        </div>
        <div class="services-container">
            
            <div class="box">
                <div class="box-img">
                    <img src="img/carro1.jpg" alt="">
                </div>
                <p>2023</p>
                <h3>Audi A3</h3>
                <h2>R$5000.00 | R$90.00 <span>/mês</span>
                <br><br>
                <a href="#" class="btn">Alugar</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/carro2.jpg" alt="">
                </div>
                <p>2023</p>
                <h3>Chevrolet Chevet</h3>
                <h2>R$3000.00 | R$83.00 <span>/mês</span>
                <br><br>
                <a href="#" class="btn">Alugar</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/carro3.jpg" alt="">
                </div>
                <p>2023</p>
                <h3>Fiat Palio</h3>
                <h2>$50000 | $358 <span>/mês</span>
                <br><br>
                <a href="#" class="btn">Alugar</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/carro4.jpg" alt="">
                </div>
                <p>2023</p>
                <h3>Fiat Tempra</h3>
                <h2>$50000 | $358 <span>/mês</span>
                <br><br>
                <a href="#" class="btn">Alugar</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/carro5.jpg" alt="">
                </div>
                <p>2023</p>
                <h3>Volkswagen Fusca</h3>
                <h2>$50000 | $358 <span>/mês</span>
                <br><br>
                <a href="#" class="btn">Alugar</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/carro6.jpg" alt="">
                </div>
                <p>2023</p>
                <h3>Volkswagen Gol G4</h3>
                <h2>$50000 | $358 <span>/mês</span>
                <br><br>
                <a href="#" class="btn">Alugar</a>
            </div>
        </div>
    </section>

    <br><br><br><br><br><br>

    <!-- Footer -->
    <section class="footer">
        <div class="footer-container container">
            <div class="footer-box">
                <a href="#" class="logo">Aloca<span>liso</span></a>
                <div class="social">
                    <a href="#"><i class='bx bxl-facebook'></i></a>
                    <a href="#"><i class='bx bxl-twitter' ></i></a>
                    <a href="#"><i class='bx bxl-youtube' ></i></a>
                </div>
            </div>
            
            
            <div class="footer-box">
                <h3>Legalidade</h3>
                <a href="">Privacidade</a>
                <a href="">Reembolso</a>

            </div>

            <div class="footer-box">
                <h3>Contatos</h3>
                <p>Manaus</p>
                <p>Acre</p>
                <p>Vale do Rio Doce</p>
            </div>
        </div>	
    </section>
</body>
</html>