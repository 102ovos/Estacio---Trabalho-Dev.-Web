<?php include_once "config.php";

?>

<?php
$nome = $_POST['nome'];
$email= $_POST['email'];
$senha= $_POST['senha'];

$sql = "INSERT INTO tbclientes(nome, email, senha) VALUES('$nome','$email','$senha')"
?>