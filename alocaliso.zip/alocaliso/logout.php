<?php
    session_start();
    unset($_SESSION["email"]);
    unset($_SESSION["nome"]);
    unset($_SESSION["tipo"]);

    session_destroy();
    header("Location: entrar_pagina.php");
    exit;
?>